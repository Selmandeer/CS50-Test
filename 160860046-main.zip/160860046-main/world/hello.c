/*#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int change_owed;

    // Prompt user for change owed until a valid positive number is given
    do
    {
        change_owed = get_int("Change owed (in cents): ");
    }
    while (change_owed < 0);

    // Initialize variables to count coins
    int quarters = 0, dimes = 0, nickels = 0, pennies = 0;

    // Calculate the number of each type of coin
    while (change_owed >= 25)
    {
        quarters++;
        change_owed -= 25;
    }
    while (change_owed >= 10)
    {
        dimes++;
        change_owed -= 10;
    }
    while (change_owed >= 5)
    {
        nickels++;
        change_owed -= 5;
    }
    while (change_owed >= 1)
    {
        pennies++;
        change_owed -= 1;
    }

    // Calculate the total number of coins
    int total_coins = quarters + dimes + nickels + pennies;

    // Print the total number of coins
    printf("%i\n", total_coins);

    return 0;
}

#include <cs50.h>
#include <stdio.h>

int calculate_quarters(int cents);
int calculate_dimes(int cents);
int calculate_nickels(int cents);
int calculate_pennies(int cents);
int quarters = 0;
int dimes = 0;
int nickels = 0;
int pennies = 0;
int total_coins(int cents);

int main(void)
{
    int cents;
    do
    {
        cents = get_int("Change owed: ");
    }
    while (cents < 0);
    while cents >= 25
        cents -= 25;
        quarters++;
    while cents >= 10
        cents -= 10;
        dimes ++;
    while cents >= 5
        cents -= 5
        nickels++;
    while cents >= 1
        cents -= 1
        pennies++;



    quarters = calculate_quarters(cents);
    dimes = calculate_dimes(cents);
    nickels = calculate_nickels(cents);
    pennies  = calculate_pennies(cents);

    total_coins(cents);
    return cents;


}

int calculate_quarters(int cents)
{
     quarters = 0;
    while (cents >= 25)
    {
        cents -= 25;
        quarters++;
    }
    return quarters;
}
int calculate_dimes(int cents)
{
     dimes = 0;
    while (cents >= 10)
    {
        cents -= 10;
        dimes++;
    }
    return dimes;
}
int calculate_nickels(int cents)
{
     nickels = 0;
    while (cents >= 5)
    {
        cents -= 5;
        nickels++;
    }
    return nickels;
}
int calculate_pennies(int cents)
{
    pennies = 0;
    while (cents >= 1)
    {
        cents -= 1;
        pennies++;
    }
    return pennies;
}
int total_coins(int cents)
{

    int total_coins = quarters + dimes + nickels + pennies;
    printf("%d\n", total_coins);
    return total_coins;

}
*/
#include <stdio.h>
#include <cs50.h>

int main(void)
{
    printf("hello world \n");
}
