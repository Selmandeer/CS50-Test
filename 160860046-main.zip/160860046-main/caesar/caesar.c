#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

bool only_digits(string s);
char rotate(char c, int n);

int main(int argc, string argv[1])
{
    if (argc != 2)
    {

        printf("Usage: ./caesar key\n");
        return 1;
    }
    else if (!only_digits(argv[1]))
    {
        printf("Usage: ./caesar key\n");
        return 1;
    }

    int number = atoi(argv[1]);
    string plaintext1 = get_string("plaintext: ");
    int i;
    int n = strlen(plaintext1);
    char ciphertext[n + 1];

    for (i = 0; i < n; i++)
    {
        ciphertext[i] = rotate(plaintext1[i], number);
    }
    ciphertext[n] = '\0';
    printf("ciphertext: %s\n", ciphertext);
    return 0;
}

bool only_digits(string s)
{
    int i;
    int n = strlen(s);
    for (i = 0; i < n; i++)
        if (!isdigit(s[i]))
        {
            return false;
        }

    return true;
}
char rotate(char c, int n)
{
    if (isupper(c))
    {
        c = ((c - 'A' + n) % 26) + 'A';
        return c;
    }
    if (islower(c))
    {
        c = ((c - 'a' + n) % 26) + 'a';
        return c;
    }
    else
        return c;
}

// 1st - start program while simulteasnusly assuming user will provide K
// 2nd - if user inputs empty sapce or or more than 1 command line argument then output error
// message "Usage: ./caesar key"
//  so step 1 is to check is user inputted K correctly
//  - prompt user for plaintext
//  take user input and see if "isupper" or "islower"
//  step 3 wrap around accoring to ASCII 26 letters of alphabet (if overflow to 27+ go back to "A"
//  not "/") step 4

// - get key
// get plaintext
// calculate cypher text
// printf cyphertext
