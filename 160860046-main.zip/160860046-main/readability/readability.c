#include <cs50.h>
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

int count_letters(string text);
int count_words(string text);
int count_sentences(string text);
float colemanindex(int letters, int words, int sentences);

int main(void)
{
    string string1 = get_string("text: ");
    int letters = count_letters(string1);
    int words = count_words(string1);
    int sentences = count_sentences(string1);
    float index = colemanindex(letters, words, sentences);

    if (index >= 16)
        printf("Grade 16+\n");
    else if (index < 1)
        printf("Before Grade 1\n");
    else
        printf("Grade %i\n", (int) index);
}

int count_letters(string text)
{
    int length = 0;
    int i;
    int n = strlen(text);
    for (i = 0; i < n; i++)
        if (isalpha(text[i]))
            length++;

    return length;
}
int count_words(string text)
{
    int length = 1;
    int i;
    int n = strlen(text);
    for (i = 0; i < n; i++)
        if (isspace(text[i]))
            length++;

    return length;
}
int count_sentences(string text)
{
    int length = 0;
    int i;
    int n = strlen(text);
    for (i = 0; i < n; i++)
        if (text[i] == '.' || text[i] == '?' || text[i] == '!')
            length++;

    return length;
}
float colemanindex(int letters, int words, int sentences)
{
    float colemanindex = ((0.0588 * ((float) letters / words) * 100) -
                          (0.296 * ((float) sentences / words) * 100) - 15.8);

    return round(colemanindex);
}

// prompt user for text
// calculate number of letters, words, and sentences
// calculate average number of letters per 100 words
// calculate avg number of sentences per 100 words
