#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int array[10];
    array[0] = 1;
    printf("%i\n", array[1]);
    for (int i = 1; i < 10; i++)
    {
        array[i] = array[i - 1] * 2;
        printf("%i\n", array[i]);
    }




}
