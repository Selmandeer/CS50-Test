#include <cs50.h>
#include <stdio.h>

int quarters = 0;
int dimes = 0;
int nickels = 0;
int pennies = 0;
int total_coins(int cents);

int main(void)
{
    int cents;
    do
    {
        cents = get_int("Change owed: ");
    }
    while (cents < 0);
    while (cents >= 25)
    {
        cents -= 25;
        quarters++;
    }
    while (cents >= 10)
    {
        cents -= 10;
        dimes++;
    }
    while (cents >= 5)
    {
        cents -= 5;
        nickels++;
    }
    while (cents >= 1)
    {
        cents -= 1;
        pennies++;
    }

    total_coins(cents);
    return cents;
}

int calculate_quarters(int cents)
{
    quarters = 0;
    while (cents >= 25)
    {
        cents -= 25;
        quarters++;
    }
    return quarters;
}
int calculate_dimes(int cents)
{
    dimes = 0;
    while (cents >= 10)
    {
        cents -= 10;
        dimes++;
    }
    return dimes;
}
int calculate_nickels(int cents)
{
    nickels = 0;
    while (cents >= 5)
    {
        cents -= 5;
        nickels++;
    }
    return nickels;
}
int calculate_pennies(int cents)
{
    pennies = 0;
    while (cents >= 1)
    {
        cents -= 1;
        pennies++;
    }
    return pennies;
}
int total_coins(int cents)
{

    int total_coins = quarters + dimes + nickels + pennies;
    printf("%d\n", total_coins);
    return total_coins;
}
